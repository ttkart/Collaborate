from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView, CreateView
from django.core.files.storage import FileSystemStorage
from django.urls import reverse_lazy

from .forms import DocForm
from .models import Document


class Home(TemplateView):
    template_name = 'home.html'


def upload(request):
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        context['url'] = fs.url(name)
    return render(request, 'upload.html', context)


def document_list(request):
    docs = Document.objects.all()
    return render(request, 'doc_list.html', {
        'books': docs
    })


def upload_doc(request):
    if request.method == 'POST':
        form = DocForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = DocForm()
    return render(request, 'upload_document.html', {
        'form': form
    })


def delete_doc(request, pk):
    if request.method == 'POST':
        document = Document.objects.get(pk=pk)
        document.delete()
    return redirect('book_list')


class DocListView(ListView):
    model = Document
    template_name = 'class_doc_list.html'
    context_object_name = 'books'


class UploadDocView(CreateView):
    model = Document
    form_class = DocForm
    success_url = reverse_lazy('class_book_list')
    template_name = 'upload_document.html'
